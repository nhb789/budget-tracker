# 简单记账工具（Budget Tracker）

一个基于 Python 的命令行记账工具，支持：

- 添加收入/支出记录
- 查看所有记录
- 查看总收入、总支出、结余
- 自动保存数据到 data.json

---

## 🚀 使用方法

安装好 Python 后，直接运行：

```bash
python main.py
